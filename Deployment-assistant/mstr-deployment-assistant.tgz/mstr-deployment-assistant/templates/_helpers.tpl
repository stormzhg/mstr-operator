{{- define "mstr-deployment-assistant.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "mstr-deployment-assistant.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "mstr-deployment-assistant.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "mstr-deployment-assistant.serviceAccountName" -}}
{{- default (include "mstr-deployment-assistant.fullname" .) .Values.rbac.serviceAccountName }}
{{- end }}

{{/*
Full image reference. image.fullName, when set, wins outright -- it is the
escape hatch for a registry/repo/tag string the chart cannot predict (e.g. a
customer's own registry after docker_pull_script.sh re-pushes the image).
Otherwise repository:tag is used, with tag defaulted by the packaging
pipeline so a chart pulled straight from CMC already names the image it was
built against.
*/}}
{{- define "mstr-deployment-assistant.image" -}}
{{- if .Values.image.fullName -}}
{{- .Values.image.fullName -}}
{{- else -}}
{{- if not .Values.image.repository -}}
{{- fail "image.repository (or image.fullName) is required" -}}
{{- end -}}
{{- if not .Values.image.tag -}}
{{- fail "image.tag (or image.fullName) is required" -}}
{{- end -}}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag -}}
{{- end -}}
{{- end }}
{{/*
The execution mode, normalised: "compatibility" or "enhanced", whatever case or
surrounding spaces it was given in. A value typed as `Compatibility` - easy with
`--set` from PowerShell, cmd or bash alike - used to match neither, so the chart
silently created no RBAC and the pod reported a mode nothing recognised.
*/}}
{{- define "mstr-deployment-assistant.executionMode" -}}
{{- $mode := .Values.rbac.executionMode | toString | trim | lower -}}
{{- if not (has $mode (list "compatibility" "enhanced")) -}}
{{- fail (printf "rbac.executionMode must be \"compatibility\" or \"enhanced\", not %q" (.Values.rbac.executionMode | toString)) -}}
{{- end -}}
{{- $mode -}}
{{- end }}

{{/*
Whether the pod may execute mstrcli, as "true" or "false".

Unset, it follows the mode: compatibility is the mode that installs, so it
executes; enhanced refuses every plan before execution matters, so it does not.
Set explicitly - a boolean from a values file or `--set`, or the string from
`--set-string` - it is honoured either way, which keeps `execution.enabled:
false` for the UI-less jumpstation deployment.
*/}}
{{- define "mstr-deployment-assistant.executionEnabled" -}}
{{- $enabled := .Values.execution.enabled -}}
{{- if or (eq (kindOf $enabled) "invalid") (eq ($enabled | toString | trim) "") -}}
{{- ternary "true" "false" (eq (include "mstr-deployment-assistant.executionMode" .) "compatibility") -}}
{{- else -}}
{{- $answer := $enabled | toString | trim | lower -}}
{{- if not (has $answer (list "true" "false")) -}}
{{- fail (printf "execution.enabled must be true or false (or left unset to follow rbac.executionMode), not %q" ($enabled | toString)) -}}
{{- end -}}
{{- $answer -}}
{{- end -}}
{{- end }}
